<?php 

	include "timp.php";

	$timp = Timp::get_current_hour();
	echo($timp);

?>